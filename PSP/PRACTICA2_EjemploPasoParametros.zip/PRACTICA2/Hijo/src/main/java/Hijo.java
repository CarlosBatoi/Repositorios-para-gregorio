public class Hijo {

    public static void main(String args[])
    {
        System.out.println("Parámetros pasados al hijo: ");

        for (String s : args)
        {
            System.out.print(s + " ");
        }
        System.out.println();
    }

}
